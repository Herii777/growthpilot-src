import type { Variants } from 'framer-motion'

export const ease = {
  default: [0.25, 0.1, 0.25, 1] as const,
  reveal: [0.16, 1, 0.3, 1] as const,
  spring: { type: 'spring' as const, stiffness: 300, damping: 30 },
}

export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: ease.reveal },
  },
}

export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { duration: 0.6, ease: ease.default },
  },
}

export const scaleIn: Variants = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.6, ease: ease.reveal },
  },
}

export const clipReveal: Variants = {
  hidden: { clipPath: 'inset(0 0 100% 0)' },
  visible: {
    clipPath: 'inset(0 0 0% 0)',
    transition: { duration: 0.8, ease: ease.reveal },
  },
}

export const staggerContainer: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.1,
    },
  },
}

export const staggerContainerFast: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.08,
    },
  },
}

export const wordReveal: Variants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: ease.reveal },
  },
}

export const cardHover = {
  rest: { y: 0, boxShadow: '0 0 0 rgba(124,58,237,0)' },
  hover: {
    y: -8,
    boxShadow: '0 20px 60px rgba(124,58,237,0.15)',
    transition: { duration: 0.3, ease: ease.default },
  },
}
