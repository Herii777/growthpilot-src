'use client'

import { useEffect } from 'react'

export function useLenis() {
  useEffect(() => {
    let lenis: InstanceType<typeof import('lenis').default> | null = null

    import('lenis').then(({ default: Lenis }) => {
      lenis = new Lenis({
        duration: 1.2,
        easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        orientation: 'vertical',
        smoothWheel: true,
      })

      let rafId: number

      function raf(time: number) {
        lenis?.raf(time)
        rafId = requestAnimationFrame(raf)
      }

      rafId = requestAnimationFrame(raf)

      return () => {
        cancelAnimationFrame(rafId)
        lenis?.destroy()
      }
    })

    return () => {
      lenis?.destroy()
    }
  }, [])
}
